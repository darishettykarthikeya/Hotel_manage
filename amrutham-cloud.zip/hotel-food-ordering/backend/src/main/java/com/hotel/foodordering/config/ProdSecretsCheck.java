package com.hotel.foodordering.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;

/** In the "prod" profile, refuse to start with placeholder secrets. */
@Component
@Profile("prod")
public class ProdSecretsCheck {
    @Value("${app.razorpay.key-secret}") private String keySecret;
    @Value("${app.razorpay.webhook-secret}") private String webhookSecret;
    @Value("${app.razorpay.key-id}") private String keyId;

    @PostConstruct
    void check() {
        if (keySecret.contains("CHANGE_ME") || webhookSecret.contains("CHANGE_ME") || keyId.contains("xxxx")) {
            throw new IllegalStateException("Razorpay keys/webhook secret are still placeholders");
        }
    }
}
