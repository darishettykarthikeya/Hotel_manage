const BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080'

/** Locally uploaded images come back as "/uploads/..." from the API; prefix them with the API address. */
export function imageSrc(url: string | null | undefined): string {
  if (!url) return ''
  return url.startsWith('/') ? BASE + url : url
}
