# Deploy (single server, Docker + automatic HTTPS)

1. Get a small Linux server (AWS EC2 t3.small / Lightsail, Ubuntu). Open ports 80 and 443.
2. Point a DNS A record (e.g. amrutham.com) at the server's IP.
3. Install Docker: `curl -fsSL https://get.docker.com | sh`
4. Copy this project to the server, then:
   ```
   cp .env.example .env     # fill in every value
   docker compose up -d --build
   ```
   Caddy fetches the HTTPS certificate automatically on first request.
5. Open https://amrutham.com/admin/login (admin@hotel.com / Admin@12345) and
   **change the admin password immediately** (update the row in `admin_users` with a new BCrypt hash).
6. Razorpay Dashboard -> Webhooks: URL `https://amrutham.com/api/payments/webhook`,
   same secret as RAZORPAY_WEBHOOK_SECRET, events `payment.captured` and `payment.failed`.
7. Test with Razorpay *test* keys first, then switch to live keys and `docker compose up -d`.

Logs: `docker compose logs -f backend`   Backups: back up the `dbdata` and `uploads` volumes
(or point DB_HOST at RDS and remove the `db` service).
